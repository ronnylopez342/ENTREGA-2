/* =========================================================
   RFC2 - Consultar reservas a traves del tiempo.

   Objetivo:
   Visualizar la evolucion de las reservas en un intervalo de
   tiempo determinado, con posibilidad de filtrar por hotel y
   por ciudad.

   Consulta para Oracle APEX / SQL Workshop.

   Para probar:
   - Cambie p_fecha_inicio y p_fecha_fin.
   - Use p_id_ciudad = NULL para consultar todas las ciudades.
   - Use p_id_hotel = NULL para consultar todos los hoteles.
   ========================================================= */

WITH parametros AS (
    SELECT
        DATE '2026-01-01' AS p_fecha_inicio,
        DATE '2026-12-31' AS p_fecha_fin,

        /* Filtros opcionales:
           Deje NULL para no aplicar el filtro.
        */
        NULL AS p_id_ciudad,
        NULL AS p_id_hotel
    FROM dual
)
SELECT
    EXTRACT(YEAR FROM r.fecha_entrada) AS anio,
    EXTRACT(MONTH FROM r.fecha_entrada) AS mes,
    c.id_ciudad,
    c.nombre AS ciudad,
    h.id_hotel,
    h.nombre AS hotel,
    COUNT(r.id_reserva) AS total_reservas,
    SUM(CASE WHEN r.estado_reserva = 'ACTIVA' THEN 1 ELSE 0 END) AS reservas_activas,
    SUM(CASE WHEN r.estado_reserva = 'FINALIZADA' THEN 1 ELSE 0 END) AS reservas_finalizadas,
    SUM(CASE WHEN r.estado_reserva = 'CANCELADA' THEN 1 ELSE 0 END) AS reservas_canceladas
FROM parametros p
JOIN reserva r
    ON r.fecha_entrada >= p.p_fecha_inicio
   AND r.fecha_entrada <= p.p_fecha_fin
JOIN hotel h
    ON h.id_hotel = r.id_hotel
JOIN ciudad c
    ON c.id_ciudad = h.id_ciudad
WHERE (p.p_id_ciudad IS NULL OR c.id_ciudad = p.p_id_ciudad)
  AND (p.p_id_hotel IS NULL OR h.id_hotel = p.p_id_hotel)
GROUP BY
    EXTRACT(YEAR FROM r.fecha_entrada),
    EXTRACT(MONTH FROM r.fecha_entrada),
    c.id_ciudad,
    c.nombre,
    h.id_hotel,
    h.nombre
ORDER BY
    anio,
    mes,
    ciudad,
    hotel;
