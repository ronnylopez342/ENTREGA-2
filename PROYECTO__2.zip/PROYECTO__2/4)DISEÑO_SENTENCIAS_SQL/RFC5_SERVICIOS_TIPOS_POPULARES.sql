/* =========================================================
   RFC5 - Consultar servicios y tipos de habitacion mas populares
          por sede por rango de fechas.

   Objetivo:
   Identificar los servicios y los tipos de habitacion mas usados
   por sede/hotel en un rango de fechas, segun las reservas realizadas.

   Consulta para Oracle APEX / SQL Workshop.

   Para probar:
   - Cambie p_fecha_inicio y p_fecha_fin.
   - Use p_id_hotel = NULL para todos los hoteles.
   - Use p_id_hotel = 1, 2, 3, etc. para una sede especifica.
   ========================================================= */

WITH parametros AS (
    SELECT
        DATE '2026-01-01' AS p_fecha_inicio,
        DATE '2026-12-31' AS p_fecha_fin,
        NULL AS p_id_hotel
    FROM dual
),
servicios_populares AS (
    SELECT
        'SERVICIO' AS categoria,
        c.nombre AS ciudad,
        h.id_hotel,
        h.nombre AS hotel,
        s.nombre AS elemento,
        COUNT(dsr.id_servicio) AS veces_usado,
        SUM(dsr.cantidad) AS cantidad_total,
        SUM(dsr.subtotal_servicio) AS valor_asociado
    FROM parametros p
    JOIN reserva r
        ON r.fecha_entrada >= p.p_fecha_inicio
       AND r.fecha_entrada <= p.p_fecha_fin
       AND r.estado_reserva IN ('ACTIVA', 'FINALIZADA')
    JOIN hotel h
        ON h.id_hotel = r.id_hotel
    JOIN ciudad c
        ON c.id_ciudad = h.id_ciudad
    JOIN detalle_servicio_reserva dsr
        ON dsr.id_reserva = r.id_reserva
    JOIN servicio s
        ON s.id_servicio = dsr.id_servicio
    WHERE (p.p_id_hotel IS NULL OR h.id_hotel = p.p_id_hotel)
    GROUP BY
        c.nombre,
        h.id_hotel,
        h.nombre,
        s.nombre
),
tipos_populares AS (
    SELECT
        'TIPO_HABITACION' AS categoria,
        c.nombre AS ciudad,
        h.id_hotel,
        h.nombre AS hotel,
        hth.nombre_tipo AS elemento,
        COUNT(r.id_reserva) AS veces_usado,
        COUNT(r.id_reserva) AS cantidad_total,
        SUM(r.precio_total) AS valor_asociado
    FROM parametros p
    JOIN reserva r
        ON r.fecha_entrada >= p.p_fecha_inicio
       AND r.fecha_entrada <= p.p_fecha_fin
       AND r.estado_reserva IN ('ACTIVA', 'FINALIZADA')
    JOIN hotel h
        ON h.id_hotel = r.id_hotel
    JOIN ciudad c
        ON c.id_ciudad = h.id_ciudad
    JOIN hotel_tipo_habitacion hth
        ON hth.id_hotel = r.id_hotel
       AND hth.id_tipo = r.id_tipo
    WHERE (p.p_id_hotel IS NULL OR h.id_hotel = p.p_id_hotel)
    GROUP BY
        c.nombre,
        h.id_hotel,
        h.nombre,
        hth.nombre_tipo
)
SELECT
    categoria,
    ciudad,
    id_hotel,
    hotel,
    elemento,
    veces_usado,
    cantidad_total,
    valor_asociado
FROM servicios_populares

UNION ALL

SELECT
    categoria,
    ciudad,
    id_hotel,
    hotel,
    elemento,
    veces_usado,
    cantidad_total,
    valor_asociado
FROM tipos_populares
ORDER BY
    hotel,
    categoria,
    veces_usado DESC,
    elemento;
