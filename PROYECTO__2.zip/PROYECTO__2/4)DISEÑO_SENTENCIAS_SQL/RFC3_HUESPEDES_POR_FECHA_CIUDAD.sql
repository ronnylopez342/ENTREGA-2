/* =========================================================
   RFC3 - Consultar la cantidad de huespedes por fechas y ciudad.

   Objetivo:
   Mostrar el numero total de huespedes en un intervalo de fechas
   para una ciudad determinada y para todos los hoteles en dicha
   ciudad. Tambien permite filtrar por hotel especifico.

   Consulta para Oracle APEX / SQL Workshop.

   Para probar:
   - Cambie p_fecha_inicio y p_fecha_fin.
   - Cambie p_id_ciudad.
   - Use p_id_hotel = NULL para ver todos los hoteles de la ciudad.
   - Use p_id_hotel = 1, 2, 3, etc. para ver un hotel especifico.
   ========================================================= */

WITH parametros AS (
    SELECT
        DATE '2026-01-01' AS p_fecha_inicio,
        DATE '2026-12-31' AS p_fecha_fin,
        1 AS p_id_ciudad,
        NULL AS p_id_hotel
    FROM dual
)
SELECT
    c.id_ciudad,
    c.nombre AS ciudad,
    h.id_hotel,
    h.nombre AS hotel,
    COUNT(r.id_reserva) AS total_reservas,
    SUM(r.num_adultos) AS total_adultos,
    SUM(r.num_menores_3_anios) AS total_menores_3_anios,
    SUM(r.num_adultos + r.num_menores_3_anios) AS total_huespedes
FROM parametros p
JOIN ciudad c
    ON c.id_ciudad = p.p_id_ciudad
JOIN hotel h
    ON h.id_ciudad = c.id_ciudad
JOIN reserva r
    ON r.id_hotel = h.id_hotel
   AND r.estado_reserva IN ('ACTIVA', 'FINALIZADA')
   AND r.fecha_entrada < p.p_fecha_fin
   AND r.fecha_salida > p.p_fecha_inicio
WHERE (p.p_id_hotel IS NULL OR h.id_hotel = p.p_id_hotel)
GROUP BY
    c.id_ciudad,
    c.nombre,
    h.id_hotel,
    h.nombre
ORDER BY
    total_huespedes DESC,
    h.nombre;
