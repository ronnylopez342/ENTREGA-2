/* =========================================================
   RFC4 - Consultar el ingreso total por hotel por rango de fechas.

   Objetivo:
   Visualizar los ingresos generados por cada hotel durante un
   rango de fechas, obteniendo agregados por ciudad y por hotel.

   Consulta para Oracle APEX / SQL Workshop.

   Para probar:
   - Cambie p_fecha_inicio y p_fecha_fin.
   - Use p_id_ciudad = NULL para todas las ciudades.
   - Use p_id_hotel = NULL para todos los hoteles.
   ========================================================= */

WITH parametros AS (
    SELECT
        DATE '2026-01-01' AS p_fecha_inicio,
        DATE '2026-12-31' AS p_fecha_fin,
        NULL AS p_id_ciudad,
        NULL AS p_id_hotel
    FROM dual
)
SELECT
    c.id_ciudad,
    c.nombre AS ciudad,
    h.id_hotel,
    h.nombre AS hotel,
    COUNT(r.id_reserva) AS total_reservas,
    SUM(r.precio_total) AS ingreso_total,
    ROUND(AVG(r.precio_total), 2) AS ingreso_promedio_por_reserva
FROM parametros p
JOIN reserva r
    ON r.fecha_entrada >= p.p_fecha_inicio
   AND r.fecha_entrada <= p.p_fecha_fin
   AND r.estado_reserva IN ('ACTIVA', 'FINALIZADA')
JOIN hotel h
    ON h.id_hotel = r.id_hotel
JOIN ciudad c
    ON c.id_ciudad = h.id_ciudad
WHERE (p.p_id_ciudad IS NULL OR c.id_ciudad = p.p_id_ciudad)
  AND (p.p_id_hotel IS NULL OR h.id_hotel = p.p_id_hotel)
GROUP BY
    c.id_ciudad,
    c.nombre,
    h.id_hotel,
    h.nombre
ORDER BY
    ingreso_total DESC,
    ciudad,
    hotel;
