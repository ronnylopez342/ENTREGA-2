/* =========================================================
   RFC1 - Consultar habitaciones disponibles para un intervalo
          de fechas en un hotel particular con ciertos criterios.

   Consulta para Oracle APEX / SQL Workshop.
   Puede ser usada por cualquier usuario, incluso sin cuenta,
   porque no depende de USUARIO, CLIENTE ni ADMINISTRADOR.

   Para probar:
   - Cambie p_id_hotel.
   - Cambie p_fecha_entrada y p_fecha_salida.
   - Deje criterios en NULL cuando no quiera filtrarlos.
   ========================================================= */

WITH parametros AS (
    SELECT
        1 AS p_id_hotel,
        DATE '2026-07-01' AS p_fecha_entrada,
        DATE '2026-07-10' AS p_fecha_salida,

        /* Criterios opcionales:
           Si quiere ignorar un criterio, dejelo en NULL.
        */
        NULL AS p_capacidad_minima,
        NULL AS p_tipo_vista,
        NULL AS p_id_tipo_cama,
        NULL AS p_id_comodidad,
        NULL AS p_id_servicio
    FROM dual
),
disponibilidad AS (
    SELECT
        h.id_hotel,
        h.nombre AS hotel,
        c.nombre AS ciudad,
        hth.id_tipo,
        hth.nombre_tipo AS tipo_habitacion,
        hth.capacidad,
        hth.dimensiones_m2,
        hth.tipo_vista,
        hth.costo_base_alta,
        hth.costo_base_baja,

        (
            SELECT COUNT(*)
            FROM habitacion hab
            WHERE hab.id_hotel = hth.id_hotel
              AND hab.id_tipo = hth.id_tipo
              AND hab.estado_habitacion = 'DISPONIBLE'
        ) AS habitaciones_fisicas_disponibles,

        (
            SELECT COUNT(*)
            FROM reserva r
            WHERE r.id_hotel = hth.id_hotel
              AND r.id_tipo = hth.id_tipo
              AND r.estado_reserva = 'ACTIVA'
              AND r.fecha_entrada < p.p_fecha_salida
              AND r.fecha_salida > p.p_fecha_entrada
        ) AS reservas_cruzadas,

        (
            (
                SELECT COUNT(*)
                FROM habitacion hab
                WHERE hab.id_hotel = hth.id_hotel
                  AND hab.id_tipo = hth.id_tipo
                  AND hab.estado_habitacion = 'DISPONIBLE'
            )
            -
            (
                SELECT COUNT(*)
                FROM reserva r
                WHERE r.id_hotel = hth.id_hotel
                  AND r.id_tipo = hth.id_tipo
                  AND r.estado_reserva = 'ACTIVA'
                  AND r.fecha_entrada < p.p_fecha_salida
                  AND r.fecha_salida > p.p_fecha_entrada
            )
        ) AS habitaciones_disponibles,

        (
            SELECT LISTAGG(tc.nombre || ' x' || htc.cantidad, ', ')
                   WITHIN GROUP (ORDER BY tc.nombre)
            FROM hotel_tipo_hab_cama htc
            JOIN tipo_cama tc
                ON tc.id_tipo_cama = htc.id_tipo_cama
            WHERE htc.id_hotel = hth.id_hotel
              AND htc.id_tipo = hth.id_tipo
        ) AS camas,

        (
            SELECT LISTAGG(co.nombre, ', ')
                   WITHIN GROUP (ORDER BY co.nombre)
            FROM hotel_tipo_hab_comodidad htc
            JOIN comodidad co
                ON co.id_comodidad = htc.id_comodidad
            WHERE htc.id_hotel = hth.id_hotel
              AND htc.id_tipo = hth.id_tipo
        ) AS comodidades,

        (
            SELECT LISTAGG(s.nombre, ', ')
                   WITHIN GROUP (ORDER BY s.nombre)
            FROM disponibilidad_servicio ds
            JOIN servicio s
                ON s.id_servicio = ds.id_servicio
            WHERE ds.id_hotel = hth.id_hotel
              AND ds.id_tipo = hth.id_tipo
        ) AS servicios_habilitados

    FROM parametros p
    JOIN hotel h
        ON h.id_hotel = p.p_id_hotel
    JOIN ciudad c
        ON c.id_ciudad = h.id_ciudad
    JOIN hotel_tipo_habitacion hth
        ON hth.id_hotel = h.id_hotel
    WHERE (p.p_capacidad_minima IS NULL OR hth.capacidad >= p.p_capacidad_minima)
      AND (p.p_tipo_vista IS NULL OR hth.tipo_vista = p.p_tipo_vista)
      AND (
            p.p_id_tipo_cama IS NULL
            OR EXISTS (
                SELECT 1
                FROM hotel_tipo_hab_cama htc
                WHERE htc.id_hotel = hth.id_hotel
                  AND htc.id_tipo = hth.id_tipo
                  AND htc.id_tipo_cama = p.p_id_tipo_cama
            )
          )
      AND (
            p.p_id_comodidad IS NULL
            OR EXISTS (
                SELECT 1
                FROM hotel_tipo_hab_comodidad htc
                WHERE htc.id_hotel = hth.id_hotel
                  AND htc.id_tipo = hth.id_tipo
                  AND htc.id_comodidad = p.p_id_comodidad
            )
          )
      AND (
            p.p_id_servicio IS NULL
            OR EXISTS (
                SELECT 1
                FROM disponibilidad_servicio ds
                WHERE ds.id_hotel = hth.id_hotel
                  AND ds.id_tipo = hth.id_tipo
                  AND ds.id_servicio = p.p_id_servicio
            )
          )
)
SELECT
    id_hotel,
    hotel,
    ciudad,
    id_tipo,
    tipo_habitacion,
    capacidad,
    dimensiones_m2,
    tipo_vista,
    costo_base_alta,
    costo_base_baja,
    habitaciones_fisicas_disponibles,
    reservas_cruzadas,
    habitaciones_disponibles,
    camas,
    comodidades,
    servicios_habilitados
FROM disponibilidad
WHERE habitaciones_disponibles > 0
ORDER BY tipo_habitacion;
