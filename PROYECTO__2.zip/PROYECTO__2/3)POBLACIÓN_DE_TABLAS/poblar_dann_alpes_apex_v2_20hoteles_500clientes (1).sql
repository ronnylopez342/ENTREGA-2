-- =========================================================
-- DANN-ALPES
-- Punto 3 - Poblacion de tablas
-- Oracle APEX / SQL Workshop
-- Archivo: poblar_dann_alpes_apex_v2_20hoteles_500clientes.sql
-- =========================================================
-- Este script puebla las 17 tablas del modelo Dann-Alpes con
-- datos suficientes para verificar los requerimientos funcionales
-- y los requerimientos funcionales de consulta.
--
-- Datos incluidos:
--   - 5 ciudades
--   - 20 hoteles diferentes
--   - 500 clientes inscritos
--   - 5 administradores
--   - 4 tipos de habitacion
--   - 4 tipos de cama
--   - 6 comodidades
--   - 11 servicios
--   - 2 temporadas
--   - 80 configuraciones hotel/tipo
--   - 560 habitaciones fisicas
--   - 500 reservas: 25 clientes distintos por hotel
--   - detalles de servicios para probar popularidad de servicios
--
-- El script primero limpia datos existentes en orden seguro y luego
-- inserta nuevamente la poblacion. No modifica la estructura.
-- =========================================================

-- =========================================================
-- 1. Limpieza de datos existentes para permitir reejecucion
-- =========================================================

DELETE FROM detalle_servicio_reserva;
DELETE FROM reserva;
DELETE FROM disponibilidad_servicio;
DELETE FROM hotel_tipo_hab_comodidad;
DELETE FROM hotel_tipo_hab_cama;
DELETE FROM habitacion;
DELETE FROM hotel_tipo_habitacion;
DELETE FROM hotel;
DELETE FROM administrador;
DELETE FROM cliente;
DELETE FROM usuario;
DELETE FROM comodidad;
DELETE FROM tipo_cama;
DELETE FROM tipo_habitacion;
DELETE FROM temporada;
DELETE FROM servicio;
DELETE FROM ciudad;
COMMIT;

-- =========================================================
-- 2. Insercion de datos de prueba
-- =========================================================

DECLARE
    TYPE t_num_tab IS TABLE OF NUMBER INDEX BY PLS_INTEGER;

    v_ciudad_id      t_num_tab;
    v_tipo_id        t_num_tab;
    v_cama_id        t_num_tab;
    v_comodidad_id   t_num_tab;
    v_servicio_id    t_num_tab;
    v_servicio_precio t_num_tab;
    v_temporada_id   t_num_tab;
    v_hotel_id       t_num_tab;
    v_cliente_id     t_num_tab;

    v_usuario_id     NUMBER;
    v_reserva_id     NUMBER;
    v_fecha_entrada  DATE;
    v_fecha_salida   DATE;
    v_temporada      NUMBER;
    v_tipo           NUMBER;
    v_client_index   NUMBER;
    v_second_service NUMBER;
    v_precio_base    NUMBER;
    v_precio_total   NUMBER;
    v_habitacion_num NUMBER;
BEGIN
    -- -----------------------------------------------------
    -- Ciudades
    -- -----------------------------------------------------
    INSERT INTO ciudad (nombre) VALUES ('Bogota') RETURNING id_ciudad INTO v_ciudad_id(1);
    INSERT INTO ciudad (nombre) VALUES ('Medellin') RETURNING id_ciudad INTO v_ciudad_id(2);
    INSERT INTO ciudad (nombre) VALUES ('Cartagena') RETURNING id_ciudad INTO v_ciudad_id(3);
    INSERT INTO ciudad (nombre) VALUES ('Cali') RETURNING id_ciudad INTO v_ciudad_id(4);
    INSERT INTO ciudad (nombre) VALUES ('Barranquilla') RETURNING id_ciudad INTO v_ciudad_id(5);

    -- -----------------------------------------------------
    -- Tipos de habitacion
    -- -----------------------------------------------------
    INSERT INTO tipo_habitacion (nombre_base) VALUES ('Estandar') RETURNING id_tipo INTO v_tipo_id(1);
    INSERT INTO tipo_habitacion (nombre_base) VALUES ('Doble') RETURNING id_tipo INTO v_tipo_id(2);
    INSERT INTO tipo_habitacion (nombre_base) VALUES ('Suite Junior') RETURNING id_tipo INTO v_tipo_id(3);
    INSERT INTO tipo_habitacion (nombre_base) VALUES ('Suite Presidencial') RETURNING id_tipo INTO v_tipo_id(4);

    -- -----------------------------------------------------
    -- Tipos de cama
    -- -----------------------------------------------------
    INSERT INTO tipo_cama (nombre) VALUES ('King') RETURNING id_tipo_cama INTO v_cama_id(1);
    INSERT INTO tipo_cama (nombre) VALUES ('Queen') RETURNING id_tipo_cama INTO v_cama_id(2);
    INSERT INTO tipo_cama (nombre) VALUES ('Doble') RETURNING id_tipo_cama INTO v_cama_id(3);
    INSERT INTO tipo_cama (nombre) VALUES ('Single') RETURNING id_tipo_cama INTO v_cama_id(4);

    -- -----------------------------------------------------
    -- Comodidades
    -- -----------------------------------------------------
    INSERT INTO comodidad (nombre) VALUES ('Wifi') RETURNING id_comodidad INTO v_comodidad_id(1);
    INSERT INTO comodidad (nombre) VALUES ('Minibar') RETURNING id_comodidad INTO v_comodidad_id(2);
    INSERT INTO comodidad (nombre) VALUES ('Aire acondicionado') RETURNING id_comodidad INTO v_comodidad_id(3);
    INSERT INTO comodidad (nombre) VALUES ('Television') RETURNING id_comodidad INTO v_comodidad_id(4);
    INSERT INTO comodidad (nombre) VALUES ('Bano privado') RETURNING id_comodidad INTO v_comodidad_id(5);
    INSERT INTO comodidad (nombre) VALUES ('Calefaccion') RETURNING id_comodidad INTO v_comodidad_id(6);

    -- -----------------------------------------------------
    -- Servicios de base del enunciado
    -- -----------------------------------------------------
    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Cancelacion flexible', 'Cancelacion permitida hasta un dia antes.', 'FIJO', 50000, 'RESERVA')
    RETURNING id_servicio INTO v_servicio_id(1);
    v_servicio_precio(1) := 50000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Airport shuttle', 'Transporte aeropuerto hotel.', 'FIJO', 90000, 'RESERVA')
    RETURNING id_servicio INTO v_servicio_id(2);
    v_servicio_precio(2) := 90000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Check-in temprano', 'Ingreso antes de la hora estandar.', 'FIJO', 60000, 'RESERVA')
    RETURNING id_servicio INTO v_servicio_id(3);
    v_servicio_precio(3) := 60000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Check-out tardio', 'Salida despues de la hora estandar.', 'FIJO', 65000, 'RESERVA')
    RETURNING id_servicio INTO v_servicio_id(4);
    v_servicio_precio(4) := 65000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Cuna para bebe', 'Cuna adicional para menores.', 'FIJO', 30000, 'NOCHE')
    RETURNING id_servicio INTO v_servicio_id(5);
    v_servicio_precio(5) := 30000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Acceso a sauna', 'Acceso a zona humeda del hotel.', 'FIJO', 40000, 'PERSONA')
    RETURNING id_servicio INTO v_servicio_id(6);
    v_servicio_precio(6) := 40000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Desayuno', 'Desayuno diario por huesped.', 'CONSUMO', 35000, 'PERSONA')
    RETURNING id_servicio INTO v_servicio_id(7);
    v_servicio_precio(7) := 35000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Valet Parking', 'Servicio de parqueadero asistido.', 'CONSUMO', 45000, 'NOCHE')
    RETURNING id_servicio INTO v_servicio_id(8);
    v_servicio_precio(8) := 45000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Almuerzo', 'Almuerzo por huesped.', 'CONSUMO', 55000, 'PERSONA')
    RETURNING id_servicio INTO v_servicio_id(9);
    v_servicio_precio(9) := 55000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Servicio de masajes', 'Sesion de masaje individual.', 'CONSUMO', 120000, 'PERSONA')
    RETURNING id_servicio INTO v_servicio_id(10);
    v_servicio_precio(10) := 120000;

    INSERT INTO servicio (nombre, descripcion_corta, tipo_costo, precio, frecuencia_aplicacion)
    VALUES ('Plan de deportes', 'Actividades deportivas del hotel.', 'CONSUMO', 70000, 'PERSONA')
    RETURNING id_servicio INTO v_servicio_id(11);
    v_servicio_precio(11) := 70000;

    -- -----------------------------------------------------
    -- Temporadas
    -- -----------------------------------------------------
    INSERT INTO temporada (nombre, fecha_inicio, fecha_fin, tipo_temporada)
    VALUES ('Temporada baja 2026', DATE '2026-01-01', DATE '2026-05-31', 'BAJA')
    RETURNING id_temporada INTO v_temporada_id(1);

    INSERT INTO temporada (nombre, fecha_inicio, fecha_fin, tipo_temporada)
    VALUES ('Temporada alta 2026', DATE '2026-06-01', DATE '2026-12-31', 'ALTA')
    RETURNING id_temporada INTO v_temporada_id(2);

    -- -----------------------------------------------------
    -- Administradores
    -- -----------------------------------------------------
    FOR i IN 1..5 LOOP
        INSERT INTO usuario (correo, password, rol)
        VALUES ('admin' || i || '@dannalpes.com', 'Admin2026!', 'ADMINISTRADOR')
        RETURNING id_usuario INTO v_usuario_id;

        INSERT INTO administrador (id_usuario, nivel_acceso)
        VALUES (v_usuario_id, CASE WHEN i = 1 THEN 'SUPER' WHEN i <= 3 THEN 'GENERAL' ELSE 'BASICO' END);
    END LOOP;

    -- -----------------------------------------------------
    -- 500 clientes inscritos
    -- -----------------------------------------------------
    FOR i IN 1..500 LOOP
        INSERT INTO usuario (correo, password, rol)
        VALUES ('cliente' || LPAD(i, 3, '0') || '@correo.com', 'Cliente2026!', 'CLIENTE')
        RETURNING id_usuario INTO v_cliente_id(i);

        INSERT INTO cliente (id_usuario, num_documento, tipo_documento, nombres, apellidos, telefono)
        VALUES (
            v_cliente_id(i),
            TO_CHAR(1000000000 + i),
            CASE WHEN MOD(i, 3) = 0 THEN 'CE' ELSE 'CC' END,
            'Cliente ' || LPAD(i, 3, '0'),
            'Apellido ' || LPAD(i, 3, '0'),
            '300' || LPAD(i, 7, '0')
        );
    END LOOP;

    -- -----------------------------------------------------
    -- 20 hoteles diferentes: 4 por cada ciudad
    -- -----------------------------------------------------
    FOR h IN 1..20 LOOP
        INSERT INTO hotel (nombre, direccion, telefono, descripcion, id_ciudad)
        VALUES (
            'Hotel Dann-Alpes ' || LPAD(h, 2, '0'),
            'Carrera ' || (10 + h) || ' # ' || (20 + h) || ' - ' || (30 + h),
            '601' || LPAD(7000000 + h, 7, '0'),
            'Sede Dann-Alpes con servicios hoteleros, habitaciones y reservas.',
            v_ciudad_id(MOD(h - 1, 5) + 1)
        )
        RETURNING id_hotel INTO v_hotel_id(h);
    END LOOP;

    -- -----------------------------------------------------
    -- Configuracion de habitaciones, habitaciones fisicas,
    -- camas, comodidades y servicios por hotel/tipo
    -- -----------------------------------------------------
    FOR h IN 1..20 LOOP
        FOR t IN 1..4 LOOP
            INSERT INTO hotel_tipo_habitacion (
                nombre_tipo,
                costo_base_alta,
                costo_base_baja,
                cantidad_disponible,
                id_hotel,
                id_tipo,
                capacidad,
                dimensiones_m2,
                tipo_vista
            ) VALUES (
                CASE t
                    WHEN 1 THEN 'Habitacion Estandar'
                    WHEN 2 THEN 'Habitacion Doble'
                    WHEN 3 THEN 'Suite Junior'
                    ELSE 'Suite Presidencial'
                END,
                250000 + (t * 140000) + (h * 5000),
                180000 + (t * 95000) + (h * 3000),
                CASE t WHEN 1 THEN 12 WHEN 2 THEN 8 WHEN 3 THEN 5 ELSE 3 END,
                v_hotel_id(h),
                v_tipo_id(t),
                CASE t WHEN 1 THEN 2 WHEN 2 THEN 4 WHEN 3 THEN 3 ELSE 5 END,
                CASE t WHEN 1 THEN 22 WHEN 2 THEN 30 WHEN 3 THEN 42 ELSE 70 END,
                CASE MOD(h + t, 4)
                    WHEN 0 THEN 'MAR'
                    WHEN 1 THEN 'MONUMENTOS'
                    WHEN 2 THEN 'PISCINA'
                    ELSE 'ESTANDAR'
                END
            );

            -- Camas por configuracion
            IF t = 1 THEN
                INSERT INTO hotel_tipo_hab_cama (cantidad, id_hotel, id_tipo, id_tipo_cama)
                VALUES (1, v_hotel_id(h), v_tipo_id(t), v_cama_id(2));
            ELSIF t = 2 THEN
                INSERT INTO hotel_tipo_hab_cama (cantidad, id_hotel, id_tipo, id_tipo_cama)
                VALUES (2, v_hotel_id(h), v_tipo_id(t), v_cama_id(3));
            ELSIF t = 3 THEN
                INSERT INTO hotel_tipo_hab_cama (cantidad, id_hotel, id_tipo, id_tipo_cama)
                VALUES (1, v_hotel_id(h), v_tipo_id(t), v_cama_id(1));
                INSERT INTO hotel_tipo_hab_cama (cantidad, id_hotel, id_tipo, id_tipo_cama)
                VALUES (1, v_hotel_id(h), v_tipo_id(t), v_cama_id(4));
            ELSE
                INSERT INTO hotel_tipo_hab_cama (cantidad, id_hotel, id_tipo, id_tipo_cama)
                VALUES (1, v_hotel_id(h), v_tipo_id(t), v_cama_id(1));
                INSERT INTO hotel_tipo_hab_cama (cantidad, id_hotel, id_tipo, id_tipo_cama)
                VALUES (2, v_hotel_id(h), v_tipo_id(t), v_cama_id(2));
            END IF;

            -- Comodidades por configuracion
            FOR c IN 1..6 LOOP
                IF t >= 3 OR c IN (1, 3, 4, 5) THEN
                    INSERT INTO hotel_tipo_hab_comodidad (id_hotel, id_tipo, id_comodidad)
                    VALUES (v_hotel_id(h), v_tipo_id(t), v_comodidad_id(c));
                END IF;
            END LOOP;

            -- Servicios disponibles por configuracion
            FOR s IN 1..11 LOOP
                INSERT INTO disponibilidad_servicio (sobrecosto, id_hotel, id_tipo, id_servicio)
                VALUES (
                    CASE WHEN t >= 3 THEN 0 ELSE CASE WHEN s IN (10, 11) THEN 15000 ELSE 0 END END,
                    v_hotel_id(h),
                    v_tipo_id(t),
                    v_servicio_id(s)
                );
            END LOOP;

            -- Habitaciones fisicas por configuracion
            FOR n IN 1..CASE t WHEN 1 THEN 12 WHEN 2 THEN 8 WHEN 3 THEN 5 ELSE 3 END LOOP
                v_habitacion_num := (t * 100) + n;
                INSERT INTO habitacion (numero_habitacion, id_hotel, id_tipo, estado_habitacion)
                VALUES (
                    TO_CHAR(h) || '-' || TO_CHAR(v_habitacion_num),
                    v_hotel_id(h),
                    v_tipo_id(t),
                    CASE WHEN MOD(n, 11) = 0 THEN 'MANTENIMIENTO' ELSE 'DISPONIBLE' END
                );
            END LOOP;
        END LOOP;
    END LOOP;

    -- -----------------------------------------------------
    -- 500 reservas: 25 clientes distintos por hotel
    -- Esto deja una media exacta de 25 clientes por hotel.
    -- -----------------------------------------------------
    FOR h IN 1..20 LOOP
        FOR j IN 1..25 LOOP
            v_client_index := ((h - 1) * 25) + j;
            v_tipo := MOD(j - 1, 4) + 1;
            v_fecha_entrada := DATE '2026-01-05' + MOD(v_client_index * 3, 320);
            v_fecha_salida := v_fecha_entrada + (MOD(j, 5) + 1);

            IF v_fecha_entrada >= DATE '2026-06-01' THEN
                v_temporada := v_temporada_id(2);
                v_precio_base := 250000 + (v_tipo * 140000) + (h * 5000);
            ELSE
                v_temporada := v_temporada_id(1);
                v_precio_base := 180000 + (v_tipo * 95000) + (h * 3000);
            END IF;

            v_precio_total := (v_fecha_salida - v_fecha_entrada) * v_precio_base;
            v_precio_total := v_precio_total + CASE WHEN MOD(j, 2) = 0 THEN 70000 ELSE 35000 END;

            INSERT INTO reserva (
                fecha_entrada,
                fecha_salida,
                num_adultos,
                num_menores_3_anios,
                precio_total,
                estado_reserva,
                codigo_confirmacion,
                id_temporada,
                id_hotel,
                id_tipo,
                id_usuario_cliente,
                fecha_cancelacion,
                motivo_cancelacion
            ) VALUES (
                v_fecha_entrada,
                v_fecha_salida,
                MOD(j, 4) + 1,
                MOD(j + h, 2),
                v_precio_total,
                CASE WHEN MOD(v_client_index, 17) = 0 THEN 'CANCELADA'
                     WHEN v_fecha_salida < DATE '2026-07-01' THEN 'FINALIZADA'
                     ELSE 'ACTIVA'
                END,
                'DA-' || LPAD(v_client_index, 6, '0'),
                v_temporada,
                v_hotel_id(h),
                v_tipo_id(v_tipo),
                v_cliente_id(v_client_index),
                CASE WHEN MOD(v_client_index, 17) = 0 THEN v_fecha_entrada - 5 ELSE NULL END,
                CASE WHEN MOD(v_client_index, 17) = 0 THEN 'Cancelacion solicitada por el cliente' ELSE NULL END
            ) RETURNING id_reserva INTO v_reserva_id;

            -- Servicio 7: desayuno, muy frecuente para RFC5
            INSERT INTO detalle_servicio_reserva (
                cantidad,
                precio_unitario,
                id_reserva,
                id_servicio,
                subtotal_servicio
            ) VALUES (
                MOD(j, 4) + 1,
                v_servicio_precio(7),
                v_reserva_id,
                v_servicio_id(7),
                (MOD(j, 4) + 1) * v_servicio_precio(7)
            );

            -- Segundo servicio variable para generar diversidad
            v_second_service := MOD(v_client_index, 11) + 1;
            IF v_second_service = 7 THEN
                v_second_service := 8;
            END IF;

            INSERT INTO detalle_servicio_reserva (
                cantidad,
                precio_unitario,
                id_reserva,
                id_servicio,
                subtotal_servicio
            ) VALUES (
                CASE WHEN v_second_service IN (6, 9, 10, 11) THEN MOD(j, 3) + 1 ELSE 1 END,
                v_servicio_precio(v_second_service),
                v_reserva_id,
                v_servicio_id(v_second_service),
                CASE WHEN v_second_service IN (6, 9, 10, 11)
                     THEN (MOD(j, 3) + 1) * v_servicio_precio(v_second_service)
                     ELSE v_servicio_precio(v_second_service)
                END
            );

            -- Cancelacion flexible en una parte de las reservas
            IF MOD(v_client_index, 5) = 0 AND v_second_service <> 1 THEN
                INSERT INTO detalle_servicio_reserva (
                    cantidad,
                    precio_unitario,
                    id_reserva,
                    id_servicio,
                    subtotal_servicio
                ) VALUES (
                    1,
                    v_servicio_precio(1),
                    v_reserva_id,
                    v_servicio_id(1),
                    v_servicio_precio(1)
                );
            END IF;
        END LOOP;
    END LOOP;

    COMMIT;
END;
/

-- =========================================================
-- 3. Consultas de verificacion para evidencia del punto 3
-- =========================================================

SELECT COUNT(*) AS total_hoteles
FROM hotel;

SELECT COUNT(*) AS total_clientes
FROM cliente;

SELECT COUNT(*) AS total_reservas
FROM reserva;

SELECT ROUND(AVG(clientes_por_hotel), 2) AS promedio_clientes_por_hotel
FROM (
    SELECT h.id_hotel,
           COUNT(DISTINCT r.id_usuario_cliente) AS clientes_por_hotel
    FROM hotel h
    LEFT JOIN reserva r ON r.id_hotel = h.id_hotel
    GROUP BY h.id_hotel
);

SELECT h.id_hotel,
       h.nombre,
       COUNT(DISTINCT r.id_usuario_cliente) AS clientes_por_hotel
FROM hotel h
LEFT JOIN reserva r ON r.id_hotel = h.id_hotel
GROUP BY h.id_hotel, h.nombre
ORDER BY h.id_hotel;

SELECT 'CIUDAD' AS tabla, COUNT(*) AS total FROM ciudad
UNION ALL SELECT 'HOTEL', COUNT(*) FROM hotel
UNION ALL SELECT 'USUARIO', COUNT(*) FROM usuario
UNION ALL SELECT 'CLIENTE', COUNT(*) FROM cliente
UNION ALL SELECT 'ADMINISTRADOR', COUNT(*) FROM administrador
UNION ALL SELECT 'TIPO_HABITACION', COUNT(*) FROM tipo_habitacion
UNION ALL SELECT 'TIPO_CAMA', COUNT(*) FROM tipo_cama
UNION ALL SELECT 'COMODIDAD', COUNT(*) FROM comodidad
UNION ALL SELECT 'SERVICIO', COUNT(*) FROM servicio
UNION ALL SELECT 'TEMPORADA', COUNT(*) FROM temporada
UNION ALL SELECT 'HOTEL_TIPO_HABITACION', COUNT(*) FROM hotel_tipo_habitacion
UNION ALL SELECT 'HABITACION', COUNT(*) FROM habitacion
UNION ALL SELECT 'HOTEL_TIPO_HAB_CAMA', COUNT(*) FROM hotel_tipo_hab_cama
UNION ALL SELECT 'HOTEL_TIPO_HAB_COMODIDAD', COUNT(*) FROM hotel_tipo_hab_comodidad
UNION ALL SELECT 'DISPONIBILIDAD_SERVICIO', COUNT(*) FROM disponibilidad_servicio
UNION ALL SELECT 'RESERVA', COUNT(*) FROM reserva
UNION ALL SELECT 'DETALLE_SERVICIO_RESERVA', COUNT(*) FROM detalle_servicio_reserva;

-- =========================================================
-- Fin del script de poblacion
-- =========================================================
